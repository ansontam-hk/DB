﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Carts.Controllers
{
    public class ManageOrderController : Controller
    {
        
        public ActionResult Index()
        {
            using( Models.CartsEntities db = new Models.CartsEntities() )
            {
               
                var result = (from s in db.Orders 
                              select s).ToList();

                return View(result);
            }
        }

        public ActionResult Details(int id)
        {
            using (Models.CartsEntities db = new Models.CartsEntities())
            {
                
                var result = (from s in db.OrderDetails
                              where s.OrderId == id
                              select s).ToList();

                if( result.Count == 0 )
                {   
                    return RedirectToAction("Index");
                }
                else
                {
                    return View(result);
                }
            }
        }

        public ActionResult SerachByUserName(string UserName)
        {
            
            string searchUserId = null ;
            using (Models.UserEntities db = new Models.UserEntities())
            {  
                searchUserId = (from s in db.AspNetUsers
                                 where s.UserName == UserName
                                 select s.Id).FirstOrDefault();
            }
            
            if (!String.IsNullOrEmpty(searchUserId))
            {   
                using (Models.CartsEntities db = new Models.CartsEntities())
                {
                    var result = (from s in db.Orders
                                  where s.UserId == searchUserId
                                  select s).ToList();

                    return View("Index", result);
                }
            }
            else
            {   
                return View("Index", new List<Models.Order>() );
            }

        }



    }
}