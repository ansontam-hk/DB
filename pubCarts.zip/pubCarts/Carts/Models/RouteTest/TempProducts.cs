﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Carts.Models.RouteTest
{

    public class TempProducts
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }

        public static List<TempProducts> getAllproducts()
        {
            List<TempProducts> result = new List<TempProducts>();


            result.Add(new TempProducts
            {
                ID = 1,
                Name = "1",
                Price = 30.0m
            });
            result.Add(new TempProducts
            {
                ID = 2,
                Name = "2",
                Price = 50.0m
            });
            result.Add(new TempProducts
            {
                ID = 3,
                Name = "3",
                Price = 10.0m
            });
            return result; //回傳商品列表
        }
    }


}