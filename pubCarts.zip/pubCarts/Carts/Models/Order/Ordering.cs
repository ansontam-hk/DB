﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Carts.Models.OrderModel
{
    public class Ship
    {
        /// <summary>
        /// 
        /// </summary>
        [Required]
        [Display(Name = "Name")]
        [StringLength(30, ErrorMessage = "error"
            , MinimumLength = 2)]
        public string RecieverName { get; set; }



        /// <summary>
        /// 
        /// </summary>
        [Required]
        [Display(Name = "Servring Table")]
        [StringLength(256, ErrorMessage = "error"
            , MinimumLength = 1)] 
        public string RecieverAddress { get; set; }

    }
}